number = int(input("Enter a number: "))

while number > 0:
	print("*" * (number % 10))
	number = number // 10