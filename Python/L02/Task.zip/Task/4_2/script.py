sp = float(input("Iveskite knygos puslapio stori (milimetrais): "))
n = int(input("Iveskite knygos puslapiu skaiciu: "))
ka = float(input("Iveskite knygos ilgi (milimetrais): "))
kp = float(input("Iveskite knygos ploti (milimetrais): "))

p = n * sp * ka * kp

print(f"Knygos gamybai sunaudota {p} kubinaiai milimetrai popieriaus")